package com.example.cityAPI.dao;

import com.example.cityAPI.model.ApiCall;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class ApiCallDAOImpl implements ApiCallDAO {

    EntityManager entityManager;

    @Autowired
    public ApiCallDAOImpl(EntityManager entityManager){
        this.entityManager = entityManager;
    }

    @Override
//    @Transactional
    public void save(ApiCall apiCall) {
        Session currentSession = entityManager.unwrap(Session.class);

//        currentSession.save(apiCall);
        currentSession.saveOrUpdate(apiCall);

    }

    @Override
//    @Transactional
    public List<ApiCall> localFindAll() {

        //get Hibernate session
        Session currentSession = entityManager.unwrap(Session.class);

        //create query
        Query<ApiCall> theQuery = currentSession.createQuery("from apicall",ApiCall.class);

        //execute query and get result list
        List<ApiCall> apiCalls = theQuery.getResultList();

        //return the result
        return apiCalls;

    }

    @Override
    public ApiCall localFindById(int id) {

        //get hibernate session
        Session currentSession = entityManager.unwrap(Session.class);

        //get the apicall
        ApiCall apiCall = currentSession.get(ApiCall.class, id);

        //return apicall
        return apiCall;
    }

    @Override
    public void localDeleteById(int id) {

       /* //get hibernate session
        Session currentSession = entityManager.unwrap(Session.class);

        //delete object with primary key
        Query theQuery = currentSession.createQuery("delete from apicall where id = :apiCallId");
        theQuery.setParameter("apiCallId", id);
        theQuery.executeUpdate();*/

        //get hibernate session
        Session currentSession = entityManager.unwrap(Session.class);

        //get the apicall
        ApiCall apiCall = currentSession.get(ApiCall.class, id);

        //remove this apicall
//        entityManager.remove(apiCall);
        currentSession.delete(apiCall);

    }

}
