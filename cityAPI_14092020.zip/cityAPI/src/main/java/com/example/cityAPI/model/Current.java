package com.example.cityAPI.model;

import javax.persistence.Embeddable;

@Embeddable
public class Current {

    private Weather weather;
    private Pollution pollution;

    public Current(){

    }

    public Weather getWeather() {
        return weather;
    }

    public void setWeather(Weather weather) {
        this.weather = weather;
    }

    public Pollution getPollution() {
        return pollution;
    }

    public void setPollution(Pollution pollution) {
        this.pollution = pollution;
    }
}
