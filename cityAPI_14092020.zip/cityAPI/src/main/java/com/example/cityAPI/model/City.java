package com.example.cityAPI.model;

import javax.persistence.*;

//@Entity(name = "city")
@Embeddable
public class City {

//    @Transient
    private String status;

    private Data data;

    public City(){

    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
