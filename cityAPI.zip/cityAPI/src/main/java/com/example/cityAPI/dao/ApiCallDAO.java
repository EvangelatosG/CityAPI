package com.example.cityAPI.dao;

import com.example.cityAPI.model.ApiCall;
import com.example.cityAPI.model.City;
import com.example.cityAPI.model.Data;

import javax.persistence.EntityManager;

public interface ApiCallDAO {

    public void save(ApiCall apiCall);

}
