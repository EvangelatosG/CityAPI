package com.example.cityAPI.api;

import com.example.cityAPI.model.ApiCall;
import com.example.cityAPI.model.City;
import com.example.cityAPI.service.ApiCallService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

@RestController
public class ApiCallRestController {

    ApiCallService apiCallService;
    ObjectMapper mapper;
    //JSONPObject jsonpObject;

    @Autowired
    public ApiCallRestController(ApiCallService apiCallService, ObjectMapper mapper){    //, JSONPObject jsonpObject
        this.apiCallService = apiCallService;
        this.mapper = mapper;
        //this.jsonpObject = jsonpObject;
    }

    @GetMapping("/api/{city}/{state}/{country}")
    public City save(@PathVariable String city, @PathVariable String state, @PathVariable String country){

        //ObjectMapper mapper = new ObjectMapper();   //TODO: Dependency Injection??

        try {

            String weatherURL = "http://api.airvisual.com/v2/city?city="+ city +"&state="+ state +"&country="+ country +"&key=4070fdd8-e3fc-40de-8c5e-2c366434b28b";

            // read JSON file and map/convert to Java POJO:
            URL url = new URL(weatherURL);

            // Map JSON to City instance
            City theCity = mapper.readValue(url, City.class);

            ApiCall apiCall = new ApiCall();
            apiCall.setCity(theCity);

            apiCallService.save(apiCall);

            //mapper.readValue(url, jsonpObject);

            return theCity;

        }catch(MalformedURLException urlException){
            urlException.getMessage();
            return null;
        }catch (IOException ioException){
            ioException.getMessage();
            return null;
        }catch (Exception exception){
            exception.getMessage();
            return null;
        }


    }

}
