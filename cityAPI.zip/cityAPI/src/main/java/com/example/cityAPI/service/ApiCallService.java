package com.example.cityAPI.service;

import com.example.cityAPI.model.ApiCall;
import com.example.cityAPI.model.City;
import com.example.cityAPI.model.Data;

public interface ApiCallService {
    public void save(ApiCall apiCall);
}
