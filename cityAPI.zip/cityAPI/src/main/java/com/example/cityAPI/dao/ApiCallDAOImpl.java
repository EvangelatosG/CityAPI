package com.example.cityAPI.dao;

import com.example.cityAPI.model.ApiCall;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

@Repository
public class ApiCallDAOImpl implements ApiCallDAO {

    EntityManager entityManager;

    @Autowired
    public ApiCallDAOImpl(EntityManager entityManager){
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(ApiCall apiCall) {
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.save(apiCall);
    }

}
