package com.example.cityAPI;

import com.example.cityAPI.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.persistence.EntityManager;
import java.net.URL;

@SpringBootApplication
public class CityApiApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(CityApiApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		System.out.println("Run method of CommandLineRunner .");
		/*// create object mapper
		ObjectMapper mapper = new ObjectMapper();

		// read JSON file and map/convert to Java POJO:
		URL url = new URL("http://api.airvisual.com/v2/city?city=Berlin&state=Berlin&country=Germany&key=4070fdd8-e3fc-40de-8c5e-2c366434b28b");

		// Map JSON to City instance
		City theCity = mapper.readValue(url, City.class);
		System.out.println("\n---- Status ----");
		System.out.println("Status: " + theCity.getStatus());

		// Get Data info
		Data theData = theCity.getData();
		System.out.println("\n---- City Data ----");
		System.out.println("City: " + theData.getCity());
		System.out.println("State: " + theData.getState());
		System.out.println("Country: " + theData.getCountry());

		// Get location info
		Location theLocation = theData.getLocation();
		System.out.println("\n---- Coordinates ----");
		System.out.println("Type: " + theLocation.getType());
		for(double coordinate : theLocation.getCoordinates()) {
			System.out.println("Coordinate: " + coordinate);
		}

		// Get current info
		Current theCurrent = theData.getCurrent();


		// Get Weather info
		Weather theWeather = theCurrent.getWeather();
		System.out.println("\n---- Weather Info ----");
		System.out.println("ts: " + theWeather.getTs());
		System.out.println("tp: " + theWeather.getTp());
		System.out.println("pr: " + theWeather.getPr());
		System.out.println("hu: " + theWeather.getHu());
		System.out.println("ws: " + theWeather.getWs());
		System.out.println("wd: " + theWeather.getWd());
		System.out.println("ic: " + theWeather.getIc());

		// Get Pollution info
		Pollution thePollution = theCurrent.getPollution();
		System.out.println("\n---- Pollution Info ----");
		System.out.println("ts: " + thePollution.getTs());
		System.out.println("aqius: " + thePollution.getAqius());
		System.out.println("mainus: " + thePollution.getMainus());
		System.out.println("aqicn: " + thePollution.getAqicn());
		System.out.println("maincn: " + thePollution.getMaincn());

		System.out.println("===============================================");

		//Hibernate

*/

	}
}
